document.addEventListener("DOMContentLoaded", () => {
    const totalPoints = parseInt(document.getElementById('totalPoints').textContent);
    const nextMilestone = 500;
    const progressBar = document.getElementById('progressBar');

    const progressPercentage = (totalPoints / nextMilestone) * 100;

    progressBar.style.width = `${progressPercentage}%`;
});


