document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            if (email && password) {
                alert("Logged in successfully! (This is just a simulation)");
                window.location.href = "home.html"; // Replace this with your actual home page
            } else {
                alert("Please fill in all fields!");
            }
        });
    }
});
